// Netlify Function: example proxy to keep API keys server-side.
// Configure env vars in Netlify:
// SERVICE_BASE_URL, SERVICE_API_KEY
exports.handler = async (event) => {
  try {
    const baseUrl = process.env.SERVICE_BASE_URL;
    const apiKey = process.env.SERVICE_API_KEY;

    if (!baseUrl || !apiKey) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'Missing SERVICE_BASE_URL or SERVICE_API_KEY' })
      };
    }

    const url = new URL('/v1/example', baseUrl);

    const resp = await fetch(url.toString(), {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Accept': 'application/json'
      }
    });

    const text = await resp.text();
    return {
      statusCode: resp.status,
      headers: { 'Content-Type': 'application/json' },
      body: text
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err && err.message ? err.message : 'Function error' })
    };
  }
};

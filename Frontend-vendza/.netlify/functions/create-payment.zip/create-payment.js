const SANDBOX_API_BASE = "https://sandbox.moncashbutton.digicelgroup.com/Api";
const SANDBOX_GATEWAY_BASE = "https://sandbox.moncashbutton.digicelgroup.com";
const LIVE_API_BASE = "https://moncashbutton.digicelgroup.com/Api";
const LIVE_GATEWAY_BASE = "https://moncashbutton.digicelgroup.com";

function json(statusCode, body) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  };
}

function buildRedirectUrl(createPaymentResponse, gatewayBase) {
  if (createPaymentResponse && createPaymentResponse.payment_url) {
    return createPaymentResponse.payment_url;
  }

  const token =
    createPaymentResponse &&
    createPaymentResponse.payment_token &&
    createPaymentResponse.payment_token.token;

  if (!token) return null;
  return `${gatewayBase}/Payment/Redirect?token=${encodeURIComponent(token)}`;
}

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return json(405, { error: "Method Not Allowed" });
  }

  const mode = String(process.env.MONCASH_MODE || "sandbox").toLowerCase();
  const isSandbox = mode !== "live";

  const clientId = isSandbox
    ? (process.env.MONCASH_TEST_CLIENT_ID || process.env.MONCASH_CLIENT_ID)
    : (process.env.MONCASH_LIVE_CLIENT_ID || process.env.MONCASH_CLIENT_ID);
  const clientSecret = isSandbox
    ? (process.env.MONCASH_TEST_CLIENT_SECRET || process.env.MONCASH_CLIENT_SECRET)
    : (process.env.MONCASH_LIVE_CLIENT_SECRET || process.env.MONCASH_CLIENT_SECRET);
  const scope = process.env.MONCASH_SCOPE || "read,write";
  const apiBase = (process.env.MONCASH_API_BASE_URL || (isSandbox ? SANDBOX_API_BASE : LIVE_API_BASE)).replace(/\/+$/, "");
  const gatewayBase = (process.env.MONCASH_GATEWAY_BASE_URL || (isSandbox ? SANDBOX_GATEWAY_BASE : LIVE_GATEWAY_BASE)).replace(/\/+$/, "");

  if (!clientId || !clientSecret) {
    return json(500, {
      error: "Missing MonCash credentials for current mode",
      mode,
      expected: isSandbox
        ? "MONCASH_TEST_CLIENT_ID / MONCASH_TEST_CLIENT_SECRET (or fallback MONCASH_CLIENT_ID / MONCASH_CLIENT_SECRET)"
        : "MONCASH_LIVE_CLIENT_ID / MONCASH_LIVE_CLIENT_SECRET (or fallback MONCASH_CLIENT_ID / MONCASH_CLIENT_SECRET)"
    });
  }

  let payload = {};
  try {
    payload = JSON.parse(event.body || "{}");
  } catch (_) {
    return json(400, { error: "Invalid JSON body" });
  }

  const amount = Number(payload.amount);
  if (!Number.isFinite(amount) || amount <= 0) {
    return json(400, { error: "Amount must be a positive number" });
  }

  const orderId = String(payload.orderId || `ORDER_${Date.now()}`);

  try {
    const authHeader = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
    const tokenBody = new URLSearchParams();
    tokenBody.set("grant_type", "client_credentials");
    tokenBody.set("scope", scope);

    const authResponse = await fetch(`${apiBase}/oauth/token`, {
      method: "POST",
      headers: {
        Authorization: `Basic ${authHeader}`,
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json"
      },
      body: tokenBody.toString()
    });

    const authData = await authResponse.json();
    const accessToken = authData && authData.access_token;
    if (!authResponse.ok || !accessToken) {
      return json(502, { error: "MonCash auth failed", mode, details: authData });
    }

    const paymentResponse = await fetch(`${apiBase}/v1/CreatePayment`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      body: JSON.stringify({
        amount: Number(amount.toFixed(2)),
        orderId
      })
    });

    const paymentData = await paymentResponse.json();
    const paymentUrl = buildRedirectUrl(paymentData, gatewayBase);

    if (!paymentResponse.ok || !paymentUrl) {
      return json(502, { error: "MonCash CreatePayment failed", mode, details: paymentData });
    }

    return json(200, {
      payment_url: paymentUrl,
      order_id: orderId,
      mode
    });
  } catch (error) {
    return json(500, {
      error: "Internal create-payment error",
      details: error && error.message ? error.message : "unknown"
    });
  }
};

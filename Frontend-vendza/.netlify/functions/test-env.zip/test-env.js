exports.handler = async () => {
  const mode = String(process.env.MONCASH_MODE || "sandbox").toLowerCase();
  const isSandbox = mode !== "live";

  return {
    statusCode: 200,
    body: JSON.stringify({
      mode: mode,
      clientId: isSandbox
        ? (process.env.MONCASH_TEST_CLIENT_ID || process.env.MONCASH_CLIENT_ID ? "OK" : "MISSING")
        : (process.env.MONCASH_LIVE_CLIENT_ID || process.env.MONCASH_CLIENT_ID ? "OK" : "MISSING"),
      secret: isSandbox
        ? (process.env.MONCASH_TEST_CLIENT_SECRET || process.env.MONCASH_CLIENT_SECRET ? "OK" : "MISSING")
        : (process.env.MONCASH_LIVE_CLIENT_SECRET || process.env.MONCASH_CLIENT_SECRET ? "OK" : "MISSING"),
      scope: process.env.MONCASH_SCOPE || "read,write"
    })
  }
}

exports.handler = async (event) => {
  try {
    const body = JSON.parse(event.body || "{}")

    const paymentReference = body.payment_reference

    console.log("Transaction reçue :", paymentReference)

    // 👉 Ici tu vas vérifier le paiement via API MonCash
    // 👉 Puis mettre à jour ta base (Supabase)

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "OK" })
    }

  } catch (error) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Webhook error" })
    }
  }
}